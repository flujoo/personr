#' @title Create a ggthemr_swatch object
#' @description Given a vectors of colors, checks will be carried out to make sure colours are not duplicated and are valid. See \code{\link{define_palette}} for more details.
#' @param x Vector of colours
#' @return Object of type ggthemr_swatch
define_swatch <- function(x) {
  n <- length(x)
  if (n < 1) 
    stop('No colours provided for swatch.', call. = FALSE)
  if (n < 2) 
    stop('You must have at least two colours in the swatch (seven recommended).', call. = FALSE)
  validate_colours(x)
  if (n < 6) 
    warning('It is recommended that you provide at least seven colours for the swatch.', call. = FALSE)
  if (any(duplicated(sapply(x, unname_colour)))) 
    stop('Duplicate colours in swatch.', call. = FALSE)
  structure(x, class = 'ggthemr_swatch')
}

#' @export
#' @rdname define_swatch
ggthemr_swatch <- define_swatch
