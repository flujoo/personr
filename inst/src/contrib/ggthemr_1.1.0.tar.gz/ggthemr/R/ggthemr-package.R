#' Style ggplot2
#' 
#' ggthemr provides colour schemes and layouts for ggplot2.
#'
#' @name ggthemr
#' @docType package
#' @import ggplot2
NULL
