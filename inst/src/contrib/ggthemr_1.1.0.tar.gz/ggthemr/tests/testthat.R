library(testthat)
library(ggthemr)

test_check("ggthemr")
